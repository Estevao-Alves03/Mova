---
name: NutriGestão Precision
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d9'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#424655'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#727787'
  outline-variant: '#c2c6d8'
  surface-tint: '#0057cd'
  primary: '#0056ca'
  on-primary: '#ffffff'
  primary-container: '#026dfc'
  on-primary-container: '#fffeff'
  inverse-primary: '#b1c6ff'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dcdddd'
  on-secondary-container: '#5f6161'
  tertiary: '#a43a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cd4a00'
  on-tertiary-container: '#fffdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b1c6ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419d'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb599'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#7f2b00'
  background: '#FFFFFF'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  foreground: '#333232'
  card: '#FFFFFF'
  muted: '#F2F2F2'
  muted-foreground: '#808080'
  accent: '#EEF3FE'
  accent-foreground: '#026DFC'
  destructive: '#EF4444'
  success: '#22C55E'
  warning: '#F59E0B'
  border: '#EAEAEA'
  sidebar-gradient-start: '#015CC4'
  sidebar-gradient-mid: '#1D16AB'
  sidebar-gradient-end: '#000B38'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  data-lg:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
  data-md:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  data-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

# Design System — Pacto Estoque Pro / Estokia (Adaptado para NutriGestão Pro)

Tom: SaaS profissional, denso em informação, com respiro. Minimalista, moderna, foco em saúde e gestão clínica.
Modo padrão: Light.

Tokens semânticos:
- `--background`: oklch(1 0 0) (#FFFFFF)
- `--foreground`: oklch(0.22 0 0) (#333232)
- `--card` / `--popover`: oklch(1 0 0) (#FFFFFF)
- `--primary`: oklch(0.53 0.22 250) (#026DFC)
- `--primary-foreground`: oklch(0.985 0 0) (#FAFAFA)
- `--secondary` / `--muted`: oklch(0.965 0 0) (#F2F2F2)
- `--muted-foreground`: oklch(0.5 0 0) (#808080)
- `--accent`: oklch(0.96 0.02 250) (#EEF3FE)
- `--accent-foreground`: oklch(0.53 0.22 250) (#026DFC)
- `--destructive`: oklch(0.637 0.237 25.3) (#EF4444)
- `--success`: oklch(0.65 0.18 145.96) (#22C55E)
- `--warning`: oklch(0.769 0.188 70) (#F59E0B)
- `--border` / `--input`: oklch(0.92 0 0) (#EAEAEA)
- `--ring`: oklch(0.53 0.22 250) (#026DFC)

Sidebar Pacto com gradiente azul escuro profundo:
linear-gradient(179.28deg, #015cc4 .05%, #1d16ab 53.55%, #000b38 99.95%)

Tipografia:
- Mona Sans (corpo, UI geral, headings)
- Geist Mono (números, dados biométricos, IDs)

Border Radius:
- radius-md: 10px (botões, badges, inputs)
- radius-xl: 16px (cards, modais, painéis)
